package homework;

import java.util.Scanner;

public class Problem2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int n = (int)(Math.random()*100 + 1);

		int min = 1,max = 100;
		int x;
		for(int i = 1 ;;i++) {
			System.out.printf("[%d] Guess a number (%d-%d): ",i,min,max);
			x = sc.nextInt();
			if(x<min) {
				System.out.println("Not in range!");
				i--;
				continue;
			}
			if(x<n) {
				System.out.println("Too samall!");
				min = x + 1;
			}
			else if(x>n) {
				System.out.println("Too large!");
				max = x - 1;
			}
			else {
				System.out.println("Correct! Numver of guesses: " + i);
				break;
			}
		}
	}

}
