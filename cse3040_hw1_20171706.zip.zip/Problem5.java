package homework;

import java.util.Scanner;

public class Problem5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter exam scores of each student.");
		int n,fst = 0,snd = 0;
		int a=0,b=0;
		int arr[]=new int[5];
		Scanner sc = new Scanner(System.in);
		for(int i =1;i<=5;i++) {
			System.out.printf("Score of student %d: ",i);
			arr[i-1] = sc.nextInt();
			if(arr[i-1] > fst) {
				snd = fst;
				b= a;
				fst = arr[i-1];
				a = i;
			}
			else if(arr[i-1] > snd) {
				snd = arr[i-1];
				b = i;
			}
		}
		
		System.out.printf("The 1st place is student %d with %d points.\n",a,fst);
		System.out.printf("The 2nd place is student %d with %d points.\n",b,snd);
	}

}
