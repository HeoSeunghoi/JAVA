package homework;

import java.util.Scanner;

public class Problem4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String text = new String();
		String str = new String();
		System.out.print("Enter a text: ");
		text = sc.nextLine();
		
		int n = text.length();
		int count = 0,i,j;
		while(true) {
			System.out.print("Enter a string: ");
			str = sc.nextLine();
			
			if(str.length() == 0) {
				System.out.println("Yout must enter a string.");
				continue;
			}
			else break;
		}
		for(i = 0 ; i<(text.length() - str.length() + 1);i++) {
			for(j = 0;j<str.length();j++) {
				if(text.charAt(i+j) == str.charAt(j)) continue;
				else break;
			}
			if(j == str.length())
				count++;
		}
		System.out.printf("There are %d instances of \"%s\".", count,str);
	}
}
