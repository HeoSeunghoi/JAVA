package homework;

import java.util.Scanner;

public class Problem1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String x = new String();
		char z;
		Scanner sc = new Scanner(System.in);
		System.out.print("ASCII code teller. Enter a letter: ");
		x = sc.nextLine();
		z= x.charAt(0);
		
		if(x.length() != 1)
			System.out.println("You must input a single uppercase or nlwercase alphabet.");
		else if((int)z <65 | ((int)z > 90)&((int)z < 97) | (int)z > 122)
			System.out.println("You must input a single uppercase or nlwercase alphabet.");

		else {
			System.out.printf("The ASCII code of %c is %d\n",z,(int)z);
		
		}
	}
}