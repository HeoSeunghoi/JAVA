package homework;

import java.util.Scanner;

public class Problem3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String text = new String();
		Scanner sc = new Scanner(System.in);
		String l = new String();
		char L;
		int count = 0,n;
		
		
		System.out.print("Enter a text: ");
		text = sc.nextLine();
		while(true) {
			System.out.print("Enter a letter: ");
			l = sc.nextLine();
			if(l.length() != 1) {
				System.out.println("You must enster a single letter.");
				continue;
			}
			else {
				L = l.charAt(0);
				break;
				}
		}
		n = text.length();
		for(int i = 0 ;i<n ;i++)
			if(text.charAt(i) == L) 
				count++;
		System.out.printf("There are %d %c's in the text.",count,L);
	}

}
