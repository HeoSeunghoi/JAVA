package MP2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

class BookInfo implements Comparable<BookInfo>{
	private String bookName;
	private String price;
	private String name;
	private int rank;
	
	public BookInfo(int rank, String bName, String name, String bPrice) {
		this.bookName = bName;
		this.price = bPrice;
		this.name = name;
		this.rank = rank;
	}
	public String toString() {
		return "#"+this.rank+" "+this.bookName+", "+this.name+", "+this.price;
	}
	public int getRank() {
		return rank;
	}
	
	public int compareTo(BookInfo b) {
		if(this.rank > b.getRank()) {return -1;}
		else if(this.rank <b.getRank()) {return 1;}
		else {
			return 0;
		}
	}
}

class BookReader{
	private static ArrayList<String> lines = new ArrayList<String>();
	private static ArrayList<BookInfo> book = new ArrayList<>();
	
	public static ArrayList<BookInfo> readBooksJsoup(String path){
		String url = path;
		Document doc = null;
		String bookname = null;
		String name = "";
		String price;
		String[] arr;

		try {
			doc = Jsoup.connect(url).get();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Elements bookName = doc.select("h3 a[href]");
	    Elements authorName = doc.select("div.product-shelf-author.contributors");
	    Elements Price = doc.select("span.current a[href]");
		for(int i = 0;i<authorName.size();i++) {
			bookname = bookName.eq(i).text();
			name = authorName.eq(i).text();
			arr = name.split(",");
			name = arr[0];
			price = Price.eq(i).text();
			book.add(new BookInfo(i+1,bookname,name,price));
		}
		return book;
	}
}

public class Problem20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<BookInfo> books;
		books = BookReader.readBooksJsoup("https://www.barnesandnoble.com/b/books/_/N-1fZ29Z8q8");
		Collections.sort(books); 
		for(int i=0; i<books.size(); i++) {
			BookInfo book = books.get(i); 
			System.out.println(book);
		}
	}

}
