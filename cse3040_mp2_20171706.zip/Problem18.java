package MP2_18;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

class makeMap implements Comparable<makeMap> {
	private String name;
	private String[] arr;
	private Double price;
	public makeMap(String line) {
		arr = line.split(" ");
		name = arr[0];
		price = Double.parseDouble(arr[1]);
	}
	public String getName(){
		return this.name;
	}
	public double getPrice() {
		return this.price;
	}
	@Override
	public int compareTo(makeMap p) {
		System.out.println("sdasfd");
		if(this.price > p.getPrice()) {return 1;}
		else if(this.price <p.getPrice()) {return -1;}
		else {
			System.out.println("sdaf");
			return this.name.compareTo(p.getName());
		}
	}
}

class MapManager{
	private static String line;
	private static makeMap node;
	
	public static myMap<String, Double> readData(String path) {
		myMap<String, Double> map = new myMap<String,Double>();
		try {
			FileReader fr = new FileReader(path);
			BufferedReader br = new BufferedReader(fr);
			while(true) {
				line = br.readLine();
				if(line == null) break;
				node = new makeMap(line);
				map.put(node.getName(),node.getPrice());
			}
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		myMap<String, Double> result = sortMapByPrice(map);
		return result;
	}
	
	public static myMap<String, Double> sortMapByPrice(myMap<String, Double> map) {
	    List<Map.Entry<String, Double>> entries = new LinkedList<>(map.entrySet());
	    
	    Collections.sort(entries, new Comparator<Map.Entry<String, Double>>() {
        @Override
        public int compare(Map.Entry<String, Double> o1, Map.Entry<String, Double> o2) {
            int comparision;
            if(o1.getValue() > o2.getValue()) {comparision = 1;}
            else if(o1.getValue() < o2.getValue()) {comparision= -1;}
            else {comparision = 0;}
            return comparision == 0 ? o1.getKey().compareTo(o2.getKey()) : comparision;
            }
        });
	    
	    myMap<String, Double> result = new myMap<>();
	    for (Entry<String, Double> entry : entries) {
	        result.put(entry.getKey(), entry.getValue());
	    }
	    result.printMap(result);
	    return result;
	}
}

@SuppressWarnings({ "serial", "hiding" })
class myMap<String, Double> extends LinkedHashMap<String,Double>{
	@SuppressWarnings("unchecked")
	private java.lang.String nameprice = "";
	private Double price;
	
	@SuppressWarnings("unchecked")
	public void printMap(myMap<String,Double> map) {
		Set<Map.Entry<String,Double>> set = map.entrySet();
		Iterator<Map.Entry<String,Double>> it = set.iterator();
		while(it.hasNext()) {
			Map.Entry<String, Double> entry = it.next();
			price = ((Double) entry.getValue());
			nameprice += entry.getKey() + " "  + (String)price + "\n";
		}
	}
	public java.lang.String toString() {
		return nameprice;
	}
}

public class Problem18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String, Double> map = MapManager.readData("input.txt");
		if(map == null) {
			System.out.println("Input file not found.");
			return;
		}
		System.out.println(map);
	}

}
