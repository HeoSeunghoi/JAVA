package MP2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

class Element implements Comparable<Element>{
	public String data;
	public double price;
	public String[] arr;

	public Element(String str) {
		arr = str.split(" ");
		this.data = arr[0];
		this.price = Double.parseDouble(arr[1]);
	}
	public String getName() { return data;}
	public double getPrice() { return price;}
	public String toString() {return data + " " + price;}

	@Override
	public int compareTo(Element p) {
		if(this.price > p.getPrice()) {return 1;}
		else if(this.price <p.getPrice()) {return -1;}
		else {
			return this.data.compareTo(p.getName());
		}
	}
}

class ElementReader{
	private static String line;
	private static ArrayList<Element> list;
	private static Element fruit;
	
	public static ArrayList<Element> readElements(String str) {
		try {
			FileReader fr = new FileReader(str);
			BufferedReader br = new BufferedReader(fr);
			list = new ArrayList<Element>();
			while(true) {
				line = br.readLine();
				if(line == null) break;
				fruit = new Element(line);
				list.add(fruit);
			}
			br.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}
}

public class Problem16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Element> list = ElementReader.readElements("input.txt");
		if(list == null) {
			System.out.println("Input file not found.");
			return;
		}
		Collections.sort(list);
		Iterator<Element> it = list.iterator();
		while(it.hasNext())
			System.out.println(it.next());
	}

}