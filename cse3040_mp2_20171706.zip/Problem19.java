package MP2;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;

class BookInfo implements Comparable<BookInfo>{
	private String bookName;
	private String price;
	private String name;
	private int rank;
	
	public BookInfo(int rank, String bName, String name, String bPrice) {
		this.bookName = bName;
		this.price = bPrice;
		this.name = name;
		this.rank = rank;
	}
	public String toString() {
		return "#"+this.rank+" "+this.bookName+", "+this.name+", "+this.price;
	}
	public int getRank() {
		return rank;
	}
	
	public int compareTo(BookInfo b) {
		if(this.rank > b.getRank()) {return -1;}
		else if(this.rank <b.getRank()) {return 1;}
		else {
			return 0;
		}
	}
}

class BookReader{
	private static ArrayList<String> lines = new ArrayList<String>();
	private static ArrayList<BookInfo> book = new ArrayList<>();
	
	public static ArrayList<BookInfo> readBooks(String path){
		int rank, status,begin,end;
		String line;
		String bookName = "";
		String name = null;
		String price;
		String l;
		try {
			URL url = new URL(path);
			BufferedReader in = null;
			in = new BufferedReader(new InputStreamReader(url.openStream()));
			
			while((line = in.readLine())!=null) {
				if(line.trim().length() > 0) lines.add(line);
			}
			in.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		rank = 1;
		status = 0;
		for(int i =0;i<lines.size();i++) {
			l = lines.get(i);
			if(status == 0) {
				if(l.contains("div class=\"count\"")) { status++;}
			}
			if(status == 1) {
				if(l.contains("shadow\" alt=\"")) {
					status++;
					begin = l.indexOf("shadow\" alt=\"") + "shadow\" alt=\"".length();
					end = l.indexOf("\" />");
					bookName = l.substring(begin, end);
				}
			}
			if(status == 2){
				if(l.contains(">by <a href=\"")) {
					begin = l.indexOf("\">")+"\">".length();
					l = l.substring(begin);
					begin = l.indexOf("\">")+"\">".length();
					end = l.indexOf("</a>");
					line = l.substring(begin);
					name = l.substring(begin, end);

					status++;
				}
			}
			if(status == 3) {
				if(l.contains("Current price is")) {
					begin = l.indexOf("Current price is ")+ "Current price is ".length();
					end = l.indexOf(", Original price");
					price = l.substring(begin, end);

					book.add(new BookInfo(rank,bookName,name,price));
					status--;
					rank++;
					status = 0;
				}
			}
		}
		return book;
	}
}

public class Problem19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<BookInfo> books;
		books = BookReader.readBooks("https://www.barnesandnoble.com/b/books/_/N-1fZ29Z8q8");
		Collections.sort(books);
		for(int i=0; i<books.size(); i++) {
			BookInfo book = books.get(i);
			System.out.println(book);
		}
	}

}
