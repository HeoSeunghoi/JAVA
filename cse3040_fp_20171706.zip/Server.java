package cse3040;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;

class bookread {
   TreeMap<Book, String> map = new TreeMap<Book, String>(Book.CASE_INSENSITIVE_ORDER);
   
   public bookread(String path) {
      
      String line = "";
      String[] bookdata;
      String bookname = "";
      String author = "";
      String borrow = "";
      
      try {
         FileReader Fr = new FileReader(path);
         BufferedReader br;
         br = new BufferedReader(Fr);
         
         while(true) {
            line = br.readLine();
            if(line == null) break;
            bookdata = line.split("\t");
            bookname = bookdata[0];
            author = bookdata[1];
            borrow = bookdata[2];
            Book book = new Book(bookname,author);
            
            map.put(book,borrow);
         }

         br.close();
      } catch (IOException e) {
         System.out.println("Input file not found.");
      }
   }
   
   public void putBook(String bookname, String author) {
	   Book book = new Book(bookname,author);
	   map.put(book, "-");
   }
   
   public void update() {
	   String str = "";
	   Book bookdata;
	   try {
		   OutputStream output = new FileOutputStream("books.txt");
		   for (Entry<Book, String> entry : (map.entrySet())) {
			   str = "";
			   bookdata = entry.getKey();
			   str += bookdata.getName() + "\t" +bookdata.getAuthor() +"\t"+entry.getValue() + "\n";
			   byte[] by=str.getBytes();
			   try {
				output.write(by);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   }
	   } catch (FileNotFoundException e) {
		   // TODO Auto-generated catch block
		   e.printStackTrace();
	   }
   }
   
   public Map<Book,String> getBook(){
	   return map;
   }
   
   public void Change(String userID, String bookname) {
	   Book bookdata;
	   for (Entry<Book, String> entry : map.entrySet()) {
		    bookdata = entry.getKey();
		    if((bookdata.getName()).equalsIgnoreCase(bookname)) {
		    	map.replace(bookdata,userID);
		    	break;
		    }
		}
   }
}

class Book implements Comparable<Book>{
	public static final Comparator<? super Book> CASE_INSENSITIVE_ORDER = null;
	String bookname = "";
	String author = "";
	
	public Book(String bookname,String author) {
		this.bookname = bookname;
		this.author = author;
	}
	
	public String getName() {
		return bookname;
	}
	public String getAuthor() {
		return author;
	}

	@Override
	public int compareTo(Book o) {
 	    // TODO Auto-generated method stub
		return bookname.toLowerCase().compareTo(o.getName().toLowerCase());
	}
}

public class Server {
 	 HashMap<String,DataOutputStream> clients;
 	 bookread book;
 	 Server(){
 		 clients = new HashMap<>();
 		 Collections.synchronizedMap(clients);
 	 }
   
 	 public void start(String args) {
 		 String path = "books.txt";
 		 book = new bookread(path);
 		 ServerSocket serverSocket = null;
 		 Socket socket = null;
 		 try {
 			 serverSocket = new ServerSocket(Integer.parseInt(args));
 			 System.out.println("Server has started.");
 			 while(true) {
 				 socket = serverSocket.accept();
 				 System.out.println("a new connection from [" + socket.getInetAddress() + ":" + socket.getPort() + "]");
 				 ServerReceiver thread = new ServerReceiver(socket);
 				 thread.start();
 			 }
 		 } catch(Exception e) {}
 	 }
   
 	 public static void main(String[] args) {
 		 // TODO Auto-generated method stub
 		 if(args.length != 1) {
 			 System.out.println("Please give the port number as an argument.");
 			 System.exit(0);
 		 }
 		 new Server().start(args[0]);
 	 }
   
 	 class ServerReceiver extends Thread {
 		 Socket socket;
 		 String order;
 		 String bookname;
 		 String author;
 		 String borrow;
 		 boolean flag = false;
 		 DataInputStream in;
 		 DataOutputStream out;
      
 		 ServerReceiver(Socket socket) {
 			 this.socket = socket;
 			 try {
 				 in = new DataInputStream(socket.getInputStream());
 				 out = new DataOutputStream(socket.getOutputStream());
 			 } catch(Exception e) {}
 		 }
      
 		 public void run() {
         String name = "";
         
         try {
            while (in != null) {
            	flag = false;
            	Book bookdata;
            	String check;
            	String userID;
            	String returnName;
            	String borrow;
            	order = in.readUTF();
            	if(order.equals("add")) {
            		bookname = in.readUTF();
            		author = in.readUTF();
            		for (Entry<Book, String> entry : (book.getBook()).entrySet()) {
            		    bookdata = entry.getKey();
            		    if((bookdata.getName()).equalsIgnoreCase(bookname)) {
            		    	flag = true;
            		    	break;
            		    }
            		}
            		if(flag == true) {
            			out.writeUTF("The book already exists in the list.");
            		} else {
            			book.putBook(bookname, author);
            			book.update();
            			out.writeUTF("A new book added to the list.");
            		}
            	} else if(order.equals("borrow")) {
            		userID = in.readUTF();
            		borrow = in.readUTF();
            		for (Entry<Book, String> entry : (book.getBook()).entrySet()) {
            		    bookdata = entry.getKey();
            		    if((bookdata.getName()).equalsIgnoreCase(borrow)) {
            		    	flag = true;
            		    	check = entry.getValue();
            		    	if(check.equals("-")) {
            		    		book.Change(userID, borrow);
            		    		book.update();
            		    		out.writeUTF("You borrowed a book. - " + bookdata.getName());
            		    	}
            		    	else
            		    		out.writeUTF("The book is not available.");
            		    	break;
            		    }
            		} if(flag == false) {//����
            			out.writeUTF("The book is not available.");
            		}
            	} else if(order.equals("return")) {
            		userID = in.readUTF();
            		returnName = in.readUTF();
            		for (Entry<Book, String> entry : (book.getBook()).entrySet()) {
            		    bookdata = entry.getKey();
            		    if((bookdata.getName()).equalsIgnoreCase(returnName)) {
            		    	flag = true;
            		    	check = entry.getValue();
            		    	if(check.equals(userID)) {
            		    		book.Change("-", returnName);
            		    		book.update();
            		    		out.writeUTF("You return a book. - " + bookdata.getName());
            		    	}
            		    	else
            		    		out.writeUTF("You did not borrow the book.");
            		    	break;
            		    }
            		} if(flag == false) {//����
            			out.writeUTF("You did not borrow the book.");
            		}
            	} else if(order.equals("info")) {
            		ArrayList<String> list = new ArrayList<>();
            		int count = 0;
            		int i;
            		int compare;
            		String str = "";
            		userID = in.readUTF();
            		for (Entry<Book, String> entry : (book.getBook()).entrySet()) {
            		    bookdata = entry.getKey();
            		    str = "";
            		    if(entry.getValue().equalsIgnoreCase(userID)) {
            		    	count+=1;
            		    	str += (bookdata.getName() + ", " + bookdata.getAuthor());
            		    	for(i=0;i<list.size();i++) {
            		    		compare = (str.toLowerCase()).compareTo(list.get(i).toLowerCase());
            		    		if(compare == -1)
            		    			break;
            		    	}
            		    	list.add(i,str);
            		    }
            		}
            		Collections.sort(list,String.CASE_INSENSITIVE_ORDER);
            		out.writeUTF(Integer.toString(list.size()));
            		out.writeUTF("You are currently borrowing "+Integer.toString(count)+" books:");
            		for(i = 0;i<list.size();i++) {
            			out.writeUTF(Integer.toString(i+1) + ". " + list.get(i));
            		}
            	} else if(order.equals("search")) {
            		ArrayList<String> list = new ArrayList<>();
            		int count = 0;
            		int i;
            		int compare;
            		String str = "";
            		String search = in.readUTF();
            		for (Entry<Book, String> entry : (book.getBook()).entrySet()) {
            		    bookdata = entry.getKey();
            		    str = "";
            		    if(bookdata.getName().matches("(?i).*"+search+".*")|bookdata.getAuthor().matches("(?i).*"+search+".*")) {
            		    	count+=1;
            		    	str += (bookdata.getName() + ", " + bookdata.getAuthor());
            		    	for(i=0;i<list.size();i++) {
            		    		compare = (str.toLowerCase()).compareTo(list.get(i).toLowerCase());
            		    		if(compare == -1)
            		    			break;
            		    	}
            		    	list.add(i,str);
            		    }
            		}
            		Collections.sort(list,String.CASE_INSENSITIVE_ORDER);
            		out.writeUTF(Integer.toString(list.size()));
            		out.writeUTF("Your search matched "+Integer.toString(count)+" results.");
            		for(i = 0;i<list.size();i++) {
            			out.writeUTF(Integer.toString(i+1) + ". " + list.get(i));
            		}
            	}
            }
         } catch(Exception e) {
         // ignore
         } finally {
            clients.remove(name);
            System.out.println("["+socket.getInetAddress()+":"+socket.getPort()+"]"+" has disconnected.");
            System.out.println("Current number of users: " + clients.size());
         }
      }
   }
   
}