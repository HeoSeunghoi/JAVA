package cse3040;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.net.Socket;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Client {
	static class ClientSender extends Thread {
		Socket socket;
		DataOutputStream out;
		DataInputStream in;
		ClientSender(Socket socket, String name) {
    		this.socket = socket;
    		try {
    			out = new DataOutputStream(socket.getOutputStream());
    			in = new DataInputStream(socket.getInputStream());
    		} catch(Exception e) {}
    	}
		
    	@SuppressWarnings("all")
    	public void run() {
    		String userID = "";
    		String pattern = "^[0-9a-z]*$";
    		String[] check;

    		System.out.print("Enter userID>> ");
    		Scanner sc = new Scanner(System.in);
    		while(true) {
    			userID = sc.nextLine();
    			check = userID.split(" ");
    			boolean regex = Pattern.matches(pattern,userID);
    			if(check.length != 1 | regex == false) {
    				System.out.println("UserID must be a single word with lowercase alphabets and numbers.");
    				System.out.print("Enter userID>> ");
    			}
    			else
    				break;
    		}
    		try {
    			String order;
    			int size;
    			System.out.println("Hello"+ " " + userID + "!");
    			while(true) {
    				System.out.print(userID+">>");
    				order = sc.nextLine();
    				if(order.equals("add")) {
    					size = add(out);
    					if(size == -1)
    						continue;
    					System.out.println(in.readUTF());
    				} else if(order.equals("borrow")) {
    					size = borrow(out,userID);
    					if(size == -1)
    						continue;
    					System.out.println(in.readUTF());
    				} else if(order.equals("return")) {
    					size = returnF(out,userID);
    					if(size == -1)
    						continue;
    					System.out.println(in.readUTF());
    				} else if(order.equals("info")) {
    					size = info(out,in,userID);
    					
    					for(int i =0;i<size;i++) {
    						System.out.println(in.readUTF());
    					}
    				} else if(order.equals("search")) {
    					size = search(out,in);
    					if(size == -1) {
    						System.out.println("Search-string must be longer than 2 characters.");
    					} else if(size == -2) {
    						continue;
    					}
    					
    					for(int i =0;i<size;i++) {
    						System.out.println(in.readUTF());
    					}
    				} else {
    					System.out.println("[available commands]");
    					System.out.println("add: add a new book to the list of books.");
    					System.out.println("borrow: borrow a book from the library.");
    					System.out.println("return: return a book to the library.");
    					System.out.println("info: show list of books I am currently borrowing.");
    					System.out.println("search: search for books.");
    				}
    					
    			}
    		} catch(Exception e) {}
    	}
	}
   
	static int add(DataOutputStream Out) {
		DataOutputStream out = Out;
		String title = "";
		String author = "";
		Scanner sc = new Scanner(System.in);
		if(out!=null) {
			try {
				out.writeUTF("add");
				System.out.print("add-title> ");
				title = sc.nextLine();
				System.out.print("add-author> ");
				author= sc.nextLine();
				if(author.trim().equals("")|title.trim().equals("")) {
					return -1;
				} else {
					out.writeUTF(title);
					out.writeUTF(author);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return 0;
	}
	   
	static int borrow(DataOutputStream Out,String userID) {
		   DataOutputStream out = Out;
		   String borrow = "";
		   Scanner sc = new Scanner(System.in);
		   if(out!=null) {
			   try {
				   out.writeUTF("borrow");
				   System.out.print("borrow-title> ");
				   borrow = sc.nextLine();
				   if(borrow.trim().equals("")) {
					   return -1;
				   } else {
					   out.writeUTF(userID);
					   out.writeUTF(borrow);
				   }
			   } catch (IOException e) {
					// TODO Auto-generated catch block
				   e.printStackTrace();
			   }
	
		   }
		   return 0;
	   }
	   
	   static int returnF(DataOutputStream Out,String userID) {
		   DataOutputStream out = Out;
		   String returnName = "";
		   Scanner sc = new Scanner(System.in);
		   if(out!=null) {
			   try {
				   out.writeUTF("return");
				   System.out.print("return-title> ");
				   returnName = sc.nextLine();
				   if(returnName.trim().equals("")) {
					   return -1;
				   } else {
					   out.writeUTF(userID);
					   out.writeUTF(returnName);
				   }
			   } catch (IOException e) {
					// TODO Auto-generated catch block
				   e.printStackTrace();
			   }
		   }
		   return 0;
	   }
	   
	   static int info(DataOutputStream Out,DataInputStream in, String userID) {
		   DataOutputStream out = Out;
		   int size = 0;
		   if(out!=null) {
			   try {
				   out.writeUTF("info");
				   
				   out.writeUTF(userID);
				   size = Integer.parseInt(in.readUTF());
				   System.out.println(in.readUTF());
			   } catch (IOException e) {
					// TODO Auto-generated catch block
				   e.printStackTrace();
			   }
		   }
		   return size;
	   }
	   
	   static int search(DataOutputStream Out, DataInputStream in) {
		   int size = 0;
		   DataOutputStream out = Out;
		   String searchWord = "";
		   Scanner sc = new Scanner(System.in);
		   if(out!=null) {
			   try {
				   out.writeUTF("search");
				   System.out.print("search-string> ");
				   searchWord = sc.nextLine();
				   if(searchWord.length() < 3) {
					   return -1;
				   } else if(searchWord.equals("")) {
					   return -2;
				   }
				   out.writeUTF(searchWord);
				   size = Integer.parseInt(in.readUTF());
				   System.out.println(in.readUTF());
			   } catch (IOException e) {
					// TODO Auto-generated catch block
				   e.printStackTrace();
			   }
		   }
		   
		   return size;
	   }
	   
	   static class ClientReceiver extends Thread {
	      Socket socket;
	      DataInputStream in;
	      ClientReceiver(Socket socket) {
	         this.socket = socket;
	         try {
	        	 in = new DataInputStream(socket.getInputStream());
	         } catch(Exception e) {}
	      }
	      
	      public void run() {
	         while (in != null) {
	            try {
	            	System.out.println(in.readUTF());
	            } catch(Exception e) {}
	         }
	      }
	   }
	   
	   public static void main(String[] args) {
	      // TODO Auto-generated method stub
	      String serverIP;
	      int port;
	      if(args.length != 2) {
	         System.out.println("Please give the IP address and port number as arguments.");
	         System.exit(0);
	      }
	      
	      try {
	
	         serverIP = args[0];
	         port = Integer.parseInt(args[1]);
	         Socket socket = new Socket(serverIP, port);
	         System.out.println("connected to server.");
	         Thread sender = new Thread(new ClientSender(socket, args[0]));
	         
	         sender.start();
	      } catch(ConnectException ce) {
	    	  System.out.println("Connection establishment failed.");
	    	  System.exit(0);
	      } catch(Exception e) {}
	   }
	}
