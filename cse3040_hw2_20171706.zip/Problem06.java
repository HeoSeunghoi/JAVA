package homework;

interface IntSequence {
	public boolean hasNext();
	public int next();
}

class FibonacciSequence implements IntSequence{
	private static int num1 = 0;
	private static int num2 = 0;
	private boolean flag = false;
	private int num;
	
	public boolean hasNext() {return true;}
	
	public int next() {
		if(num2 == 0 && num1 == 0) {
			num2 = 1;
			return 0;
		}
		else if(num2 == 1 && num1 == 0 && flag == false) {
			flag = true;
			return 1;
		}
		num = num1 + num2;
		num1 = num2;
		num2 = num;
		return num;
	}
}

public class Problem06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IntSequence seq = new FibonacciSequence();
		for(int i = 0;i<20;i++) {
			if(seq.hasNext() == false) break;
			System.out.print(seq.next() + " ");
		}
		System.out.println(" ");
	}

}
