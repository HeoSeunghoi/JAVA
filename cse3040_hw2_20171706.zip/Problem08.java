package homework;

interface Shape{
	public abstract double area();
}

class Circle implements Shape{
	private double r;
	public Circle(double r) {
		this.r = r;
	}
	public double area() {
		return Math.PI * r * r;
	}
}

class Square implements Shape{
	private double x;
	public Square(double x) {
		this.x = x;
	}
	public double area() {
		return x*x;
	}
}

class Rectangle implements Shape{
	private double A, B;
	public Rectangle(double a,double b) {
		this.A = a;
		this.B = b;
	}
	public double area() {
		return A*B;
	}
}

public class Problem08 {
	
	public static double sumArea(Shape[] arr) {
		double sum = 0;
		int i = 0;
		int n = arr.length;
		while(i<n) {
			sum += arr[i].area();
			i++;
		}
		
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape[] arr = {new Circle(5.0), new Square(4.0),
				new Rectangle(3.0, 4.0), new Square(5.0)}; 
		
		System.out.println("Total area of the shapes is: "+ sumArea(arr));
	}

}
