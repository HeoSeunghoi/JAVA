package homework;

import java.util.Scanner;

interface IntSequenceStr{
	public abstract boolean hasNext();
	public abstract int next();
}

class BinarySequenceStr implements IntSequenceStr{
	private static int num = 0;
	private static int n = 0;
	private int result;
	private boolean flag = true;
	
	public BinarySequenceStr(int num) {
		this.num = num;
	}
	public boolean hasNext() {return flag;}
	public int next() {
		while(num - (Math.pow(2, n)) >= Math.pow(2, n))
			n++;
		if(num >= Math.pow(2, n)) {
			result = 1;
			num -= Math.pow(2, n);
			n--;
		}
		else {
			result = 0;
			n--;
		}
		if(n == -1)
			flag = false;
		return result;
	}
}

public class Problem07 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.print("Enter a positive integer: ");
		String str = in.nextLine();
		int num = Integer.parseInt(str);
		in.close();
		System.out.println("Integer: " + num);
		IntSequenceStr seq = new BinarySequenceStr(num);
		System.out.print("Binary number: ");
		while(seq.hasNext()) System.out.print(seq.next());
		System.out.println(" ");
	}

}