package Exam;

class PalindromeChecker{
	private static int nLength;
	private static int number;
	private static int a = 1;
	private static int i=0, j=0;
	private static boolean flag = true;
	private static int strLength;
	private static char[] string;
	
	public static void check(int n) {
		a = 1;
		number = n;
		nLength = (int)(Math.log10(number)+1);
		for( i = 1; i<nLength; i++) {a *= 10;}
		for( i = 0; i<(nLength/2);i++) {
			if((number/a) == (number%10)) flag = true;
			else {
				flag = false;
				System.out.println(n + " is not a palindrome.");
				break;
			}
			number = ((number%a)-(number%10))/10;
			a /= 100;
			
		}
		if(flag == true)
			System.out.println(n + " is a palindrome.");
	}
	
	public static void check(String str) {
		string = new char[str.length()];
		strLength = str.length() - 1;
		j = strLength;
		for(i = 0; i<=strLength; i++) {string[i] = (str.charAt(i));}
		for(i = 0; i<(strLength+1)/2; i++) {
			if(string[i] == string[j]) flag = true;
			else {
				flag = false;
				System.out.println(str + " is not a palindrome.");
				break;
			}
			j--;
		}
		if(flag == true)
			System.out.println(str + " is a palindrome.");
	}
}

public class Problem11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PalindromeChecker.check("abcde");
		PalindromeChecker.check("abcba");
		PalindromeChecker.check(1234);
		PalindromeChecker.check(12321);
	}

}
