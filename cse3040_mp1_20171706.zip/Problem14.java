package Exam;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

class FruitBox<T>{
	private double priceSum = 0;
	private int num = 0;
	private String Max_name = "";
	private double Max_price;
	private String Min_name = "";
	private double Min_price;

	
	public void add(Fruit fruit) {
		priceSum += fruit.getPrice();
		if(num == 0) {
			Max_price = fruit.getPrice();
			Max_name = fruit.getName();
			Min_price = fruit.getPrice();
			Min_name = fruit.getName();
		}
		else if(fruit.getPrice() > Max_price) {
			Max_price = fruit.getPrice();
			Max_name = fruit.getName();
		}
		else if(fruit.getPrice() < Min_price) {
			Min_price = fruit.getPrice();
			Min_name = fruit.getName();	
		}
		
		System.out.println(fruit.getName() + " " + fruit.getPrice());
		
		num++;
	}
	public int getNumItems() {
		return num;
	}
	public String getMaxItem() {
		return Max_name;
	}
	public String getMinItem() {
		return Min_name;
	}
	public double getMaxPrice() {
		return Max_price;
	}
	public double getMinPrice() {
		return Min_price;
	}
	public double getAvgPrice() {
		return (priceSum/num);
	}
}

class Fruit{
	private String name = "";
	private double price = 0;

	public Fruit(String name, double price) {
		this.name = name;
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public double getPrice() {
		return price;
	}
}

class ItemReader{
	private static String path;
	private static double price;
	private static String name;
	private static String[] spt;
	private static String line = "";
	private static Fruit fruit;
	
	public static boolean fileToBox(String path, FruitBox box) {
		try {
			FileReader fr = new FileReader(path);
			BufferedReader br = new BufferedReader(fr);
			
			while(true) {
				line = br.readLine();
				if(line == null) break;
				String[] spt = line.split(" ");
				name = spt[0];
				price = Double.parseDouble(spt[1]);
				fruit = new Fruit(name,price);
				box.add(fruit);
			}
		} catch(IOException e) {
			System.out.println("Input file not found.");
			return false;
		}
		return true;
	}
}

public class Problem14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FruitBox<Fruit> box = new FruitBox<>();
		boolean rv = ItemReader.fileToBox("input_prob14.txt", box);
		if(rv == false) return;
		box.add(new Fruit("orange", 9.99));
		System.out.println("----------------");
		System.out.println(" Summary");
		System.out.println("----------------");
		System.out.println("number of items: " + box.getNumItems());
		System.out.println("most expensive item: " + box.getMaxItem() + " (" + box.getMaxPrice() + ")");
		System.out.println("cheapest item: " + box.getMinItem() + " (" + box.getMinPrice() + ")");
		System.out.printf("average price of items: %.2f", box.getAvgPrice());}
}
