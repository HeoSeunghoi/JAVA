package Exam;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

class Item{
	private String data = "";
	private int count = 1;
	
	public Item(String data) {
		this.data = data;
	}
	public String toString() {
		data = data + " " + Integer.toString(count);
		return data;
	}
	public void countUp() {
		count++;
	}
	public String getData() {
		return data;
	}
	public int getCount() {
		return count;
	}
}

class MyFileReader{
	private static String line;
	private static String data;
	private static String[] arr;
	private static int i,j;
	private static int arrsize = 0;
	
	@SuppressWarnings("finally")
	public static boolean readDataFromFile(String path, ArrayList<Item> list) {
		FileReader fr;
		try {
			fr = new FileReader(path);
			BufferedReader br = new BufferedReader(fr);
			while(true) {
				line = br.readLine();
				if(line == null) break;
				arr = line.split(" ");
				for(i = 0;i< arr.length;i++) {
					arr[i] = arr[i].toLowerCase();
					arrsize = list.size();
					for(j=0;j<arrsize;j++) {
						if(list.get(j).getData().equals(arr[i])) {
							list.get(j).countUp();
							break;
						}
					}
					if(j == arrsize)
						list.add(new Item(arr[i]));
				}
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			return false;
		} finally {
			return true;
		}
	}
}

public class Problem15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Item> list = new ArrayList<>();
		boolean rv = MyFileReader.readDataFromFile("input_prob15.txt", list);
		if(rv == false) {
			System.out.println("Input file not found.");
			return;
			}
		for(Item it: list)
			System.out.println(it);
	}

}
