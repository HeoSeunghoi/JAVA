package Exam;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

class Text{
	private int count = 0,i;
	private String str = "";
	private String line;
	private String string1="";
	private char[] string;
	private int strLength;
	
	public boolean readTextFromFile(String str){
		this.str = /*"src/Exam/" + */str;
		
		try {
			FileReader Fr = new FileReader(str);
			BufferedReader br;
			br = new BufferedReader(Fr);


			while(true) {
				line = br.readLine();

				if(line == null) break;
				string1 = string1 + line;
			}

			br.close();
		} catch (IOException e) {
			System.out.println("Input file not found.");
			return false;
		}
		return true;
	}
	
	public int countChar(char c) {
		count = 0;
		strLength = string1.length();
		string1 = string1.toLowerCase();
		string = new char[string1.length()];
		for(i = 0; i<strLength; i++) {
			string[i] = string1.charAt(i);
		}
		
		
		
		for(i=0;i<strLength;i++) {
			if(c == string[i]) count++;
		}
		return count;
	}
}

public class Problem13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Text t = new Text();
		if(t.readTextFromFile("input_prob13.txt")){
			for(char c = 'a'; c <= 'z'; c++) {
				System.out.println(c + ": " + t.countChar(c));
			}
		}
	}

}
