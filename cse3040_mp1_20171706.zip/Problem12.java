package Exam;

class SubsequenceChecker{
	private static int i=0,j=0;
	private static boolean flag = true;
	private static int[] arr;
	private static char[] string1;
	private static char[] string2;
	private static int strLength1;
	private static int strLength2;
	public static void check(String str1, String str2) {
		string1 = new char[str1.length()];
		string2 = new char[str2.length()];
		arr = new int[str2.length()];
		j = 0;
		
		strLength1 = str1.length() - 1;
		strLength2 = str2.length() - 1;
		for(i = 0; i<=strLength1; i++) {string1[i] = (str1.charAt(i));}
		for(i = 0; i<=strLength2; i++) {string2[i] = (str2.charAt(i));}
		
		for(i = 0; i<=strLength2; i++) {arr[i] = 0;}
		
		for(i=0;i<=strLength2;i++) {
			for(;j<=strLength1;j++) {
				if(string1[j] == string2[i]) {
					arr[i] = j;
					break;
				}
			}
			if(j > strLength1) {
				flag = false;
				break;
			}
		}
		if(flag == false)
			System.out.println(str2 + " is not a subsequence of " + str1);
		else {
			System.out.println(str2 + " is a subsequence of " + str1);
			for(i=0;i<strLength2;i++)
				System.out.print(arr[i] + " ");
			System.out.println(arr[strLength2]);
		}
	}
}

public class Problem12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SubsequenceChecker.check("supercalifragilisticexpialidocious", "pads");
		SubsequenceChecker.check("supercalifragilisticexpialidocious", "padsx");
		
	}

}
